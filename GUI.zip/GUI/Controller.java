package GUI;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

public class Controller implements Initializable {


    public TextField txtUsername;
    public PasswordField txtPassword;
    public Label LoginWarningLabel;

    public Button LoginButton;
    public Label registerWarningLabel;
    public TextField txtRegisterUsername;
    public TextField txtRegisterEmail;
    public TextField txtRegisterLastName;
    public PasswordField txtRegisterSecurityCode;
    public TextField txtRegisterPassword;
    public TextField txtRegisterFirstName;
    public Label resetWarningLabel;
    public Label registerWarningDisplay;
    public TextField txtResetUsername;
    public PasswordField txtResetPassword2;
    public PasswordField txtResetPassword;
    public TextField txtResetCode;
    @FXML
    public Button loginSignUpButton;
    @FXML
    public Button loginResetButton;
    public Label deleteWarning;
    public Button deleteButton;
    public Button deleteYes;
    public Button deleteNo;
    public TextField confirmPass;
    public TextField newPass;
    public TextField currentPass;
    public Label changePassLabel;
    public TextField chatRoomInput;
    public TextArea chatRoomDisplay;
    public TextField inputMessage;
    public Button chatRoomSendButton;
    public Label usernameDisplay;
    public ImageView userImageDisplay;
    @FXML
    private Button exitButton;
    public Circle profileCircle;

    private static Socket server;
    private static ObjectOutputStream toServer;
    private static ObjectInputStream fromServer;
    private static Account user;
    private int counter = 3; // counter for login method
    private static String serverName = "localhost";

//    private BufferedReader fromUser;


    /**
     * Constructor to create a client. The constructor opens a socket connection
     * with the server and also gets the server's input and output streams.
     *
     */
    public static void connection () {
//        String serverName = "localhost";
        System.out.println("Establishing connection. Please wait.");
        try {
            // Creates a socket to talk to serverName at port 50000.
            server = new Socket(serverName, 50000);

            // Set up the streams to send and receive messages to and from the server.

            toServer = new ObjectOutputStream(server.getOutputStream());
            fromServer = new ObjectInputStream(server.getInputStream());

            System.out.println("Connected to " + serverName);

        } catch (UnknownHostException unknownHostException) {
            System.err.println("Unknown host: " + serverName);

        } catch (IOException ioException) {
            System.err.println("Server not found.");
        }
    }

    String[] arg = new String[]{};
    public void run() {
        try {
            connection();
            GUIMain.main(arg);
        } catch (Exception ex){
            System.out.println("socket communication broke");
            closeConnection();
        }
    }
    /**
     * This closeConnection method is like a finalise method, it closes all of the
     * streams and ends the connection with the server.
     */
    public void closeConnection() {
        System.out.println("Closing the connection to " + server.getInetAddress().getHostName() + ".");
        // Close the streams
        try {
            toServer.close();
        } catch (IOException e) {
//            System.err.println("Could not close stream.");
        }

        try {
            fromServer.close();
        } catch (IOException e) {
//            System.err.println("Could not close stream.");
        }

        try {
//            fromUser.close();
        } catch (Exception e) {
//            System.err.println("Could not close stream.");
        } try {
            Platform.exit();
        } catch (Exception e){
            System.out.println(e.getMessage());
        }

        try {
            server.close();
            System.out.println("Connection closed.");
        } catch (IOException e) {
            System.out.println("Could not close connection to " + server.getInetAddress().getHostName() + ".");
        }
    }


    /**
     * This function takes the user to the Registration page when
     * activated via an action event.
     */
    @FXML
    public void signUpButtonPushed(ActionEvent event) throws IOException {
        connection();
        Parent registrationView = FXMLLoader.load(getClass().getResource("Registration.fxml"));
        Scene registrationScene = new Scene(registrationView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(registrationScene);
        window.show();
    }

    /**
     * This function takes the user to the Login page when activated via
     * an action event.
     */
    @FXML
    public void returnToLogin(ActionEvent event) throws IOException {
        Parent loginView = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene loginScene = new Scene(loginView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(loginScene);
        window.show();
    }

    /**
     * This method signs the user out of their profile
     * when activated via an action event. It returns
     * the user to the login page.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    public void signOut(ActionEvent event) throws IOException {

        String logoutProto = "8#" + user.getUserName();
        user.logout();
        toServer.reset();
        toServer.writeObject(logoutProto);


        Parent loginView = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene loginScene = new Scene(loginView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(loginScene);
        window.show();
    }

    /**
     * This method closes the application when the exit button
     * is activated by the user.
     */
    @FXML
    public void closeAppButton() {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
        try {
            sendMessages.interrupt();
            receiveMessages.interrupt();
			toServer.writeObject("11#");
			closeConnection();
		} catch (NullPointerException | IOException e) {
			try {
				server = new Socket(serverName, 50000);
				toServer = new ObjectOutputStream(server.getOutputStream());
				toServer.writeObject("11#client");
				toServer.close();
				server.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			System.out.println("Connection with server closed.");
//			e.printStackTrace();
		}
//        closeConnection();
    }

    /**
     * This method takes the user to the Reset password page
     * when the event is activated.
     */
    @FXML
    public void goToResetPasswordPage(ActionEvent event) throws IOException {
        connection();
        Parent resetPasswordView = FXMLLoader.load(getClass().getResource("ResetPassword.fxml"));
        Scene resetPasswordScene = new Scene(resetPasswordView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(resetPasswordScene);
        window.show();

    }

    /**
     * This method takes the user to the Chats page when the
     * event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToChatsPage(ActionEvent event) throws IOException {
        Parent chatsView = FXMLLoader.load(getClass().getResource("Chats.fxml"));
        Scene chatsScene = new Scene(chatsView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(chatsScene);
        window.show();
    }


    /**
     * This method takes the user to the settings page when
     * the event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToSettingsPage(ActionEvent event) throws IOException {
        Parent settingsView = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        Scene settingsScene = new Scene(settingsView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(settingsScene);
        window.show();
    }

    /**
     * This method takes the user to the New Chat page when the
     * event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToNewChatPage(ActionEvent event) throws IOException {
        Parent newChatPageView = FXMLLoader.load(getClass().getResource("NewChat.fxml"));
        Scene newChatPageScene = new Scene(newChatPageView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(newChatPageScene);
        window.show();
    }

    /**
     * This method takes the user to the Change Password page when
     * the event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToChangePasswordPage(ActionEvent event) throws IOException {
        Parent changePasswordPageView = FXMLLoader.load(getClass().getResource("ChangePassword.fxml"));
        Scene changePasswordPageScene = new Scene(changePasswordPageView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(changePasswordPageScene);
        window.show();
    }

    /**
     * This method takes the user to the Krishna Chat room page
     * when the event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToChatRoomPage(ActionEvent event) throws IOException {
        Parent chatRoomView = FXMLLoader.load(getClass().getResource("ChatRoom.fxml"));
        Scene chatRoomScene = new Scene(chatRoomView);
        receiveMessages.start();
        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(chatRoomScene);
        window.show();
        
    }

    /**
     * This method takes the user to the Delete account page when
     * the event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToDeleteAccountPage(ActionEvent event) throws IOException {
        Parent deleteAccountView = FXMLLoader.load(getClass().getResource("DeleteAccount.fxml"));
        Scene deleteAccountScene = new Scene(deleteAccountView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(deleteAccountScene);
        window.show();
    }
    
    /**
     * This method takes the user to the change image page when
     * the event is activated.
     * @param event
     * @throws IOException
     */

    @FXML
    public void goToChangeImage(ActionEvent event) throws IOException {
        Parent changeImageView = FXMLLoader.load(getClass().getResource("ChangeImage.fxml"));
        Scene changeImageScene = new Scene(changeImageView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(changeImageScene);
        window.show();
    }

    /**
     * Login.fxml
     * Displays a warning message in the Login page
     * if the user enters incorrect login credentials.
     * @param text the text to be displayed.
     * @param colour the colour the text should be displayed in.
     */
    @FXML
    private void warningDisplay(String text, Color colour) {
        LoginWarningLabel.setText(text);
        LoginWarningLabel.setTextFill(colour);

    }

    /**
     * Registration.fxml
     * Displays a warning message in the Registration page
     * if user enters incorrect login credentials.
     * @param text the text to be displayed.
     * @param colour the colour the text should be displayed in.
     */
    @FXML
    private void registerWarningDisplay(String text, Color colour) {
        registerWarningDisplay.setText(text);
        registerWarningDisplay.setTextFill(colour);
    }

    /**
     * ResetPassword.fxml
     * Displays a warning message in the ResetPassword page
     * if user enters incorrect credentials.
     * @param text
     * @param colour
     */
    @FXML
    private void resetWarningDisplay(String text, Color colour) {
        resetWarningLabel.setText(text);
        resetWarningLabel.setTextFill(colour);

    }

    /**
     *
     * @param text
     * @param colour
     */
    @FXML
    private void changePasswordStatus(String text, Color colour) {
        changePassLabel.setText(text);
        changePassLabel.setTextFill(colour);
    }

    /**
     * Login.fxml
     * Checks login credentials with database records to determine
     * whether the login details a user enters are valid or not.
     *
     * @return
     */

    @FXML
    private String userLogIn() {

        String result;
        String status;
        connection();
        try {
            String username = txtUsername.getText();
            String password = txtPassword.getText();

            toServer.reset();
            toServer.writeObject("0#" + username + "#" + password);

            result = (String) fromServer.readObject();
//            if (counter == 0) {
//                warningDisplay("No login attempts remaining, reset password", Color.RED);
//                status = "unsuccessful";
//                return status;
//}
            if (username.isEmpty() || password.isEmpty()) {
                warningDisplay("Please enter valid login details", Color.RED);
                status = "Invalid login credentials";
                return status;

            } if (!result.equals("failure")) {
                counter = 3;
                String[] accountDetails = result.split("#");
                String firstName = accountDetails[1];
                String lastName = accountDetails[2];
                String username1 = accountDetails[3];
                String email = accountDetails[4];
                String password1 = accountDetails[5];
                String securityCodeString = accountDetails[6];

                int securityCode = Integer.parseInt(securityCodeString);
                user = new Account(firstName, lastName, username1, email, password1, securityCode);

                warningDisplay("Login successful", Color.GREEN);
                status = "Login successful";
                return status;

            } else {
//                counter--;
//                warningDisplay(counter + " attempts remaining", Color.RED);
                status = "unsuccessful attempt";
                return status;
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return "unsuccessful";
        }
    }


//        if (username.isEmpty() || password.isEmpty()) {
//            warningDisplay("Please enter valid login details", Color.RED);
//            result = "Login unsuccessful";
//        } else {
//            Connection connection;
//            PreparedStatement preparedStatement;
//            try {
//
//                connection = DriverManager.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/", "krishna", "08tgfexbf8");
//                preparedStatement = connection.prepareStatement("SELECT ID, password FROM USERS WHERE ID = ? and password = ?");
//                preparedStatement.setString(1, username);
//                preparedStatement.setString(2, password);
//                ResultSet resultSet = preparedStatement.executeQuery();
//
//                if (!resultSet.next()) {
//                    warningDisplay("Invalid username and Password", Color.RED);
//                    result = "Login unsuccessful";
//                } else {
//                    warningDisplay("Login successful", Color.GREEN);
//                }
//            } catch (SQLException e) {
//                System.out.println(e.getMessage());
//            }
//        }
//        return result;
//    } catch (IOException e) {
//            e.printStackTrace();
//        }



    /**
     * Login.fxml
     * If the user enters the correct login details, the
     * Stage will be changed to Chats.fxml. If not, a warning
     * message will be displayed (linked to the login button).
     *
     * @param event
     */
    @FXML
    public void loginButtonActionEvent(ActionEvent event) {
        String username = txtUsername.getText();
        String password = txtPassword.getText();
        if (event.getSource() == LoginButton ) {
        	if (userLogIn().equals("Login successful")) {
                try {
//                  String protoLogIn = "0#" + txtUsername.getText() + "#" + txtPassword.getText();
//                  toServer.reset();
//                  toServer.writeUTF(protoLogIn);
                  Parent chatsView = FXMLLoader.load(getClass().getResource("Chats.fxml"));
                  Scene chatsScene = new Scene(chatsView);
                  //now get the stage info...
                  Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                  window.setScene(chatsScene);
                  window.show();
              } catch (IOException e) {
                  System.out.println(e.getMessage());
              }
        	} else if (username.isEmpty() || password.isEmpty()) {
            	System.out.println("test log in ");
                warningDisplay("Please enter valid login details", Color.RED);
        	} else if (!username.isEmpty() && !password.isEmpty() && counter != 1){
        		counter --;
                warningDisplay(counter + " attempts remaining", Color.RED);
        	} else if (counter == 1) {
                try{
                    connection();
                    Parent resetPasswordView = FXMLLoader.load(getClass().getResource("ResetPassword.fxml"));
                    Scene resetPasswordScene = new Scene(resetPasswordView);

                    //now get the stage info...
                    Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    window.setScene(resetPasswordScene);
                    window.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        	}
        }
    }
//        if (event.getSource() == LoginButton &&
//                userLogIn().equals("Login successful")) {
//            try {
////                String protoLogIn = "0#" + txtUsername.getText() + "#" + txtPassword.getText();
////                toServer.reset();
////                toServer.writeUTF(protoLogIn);
//                Parent chatsView = FXMLLoader.load(getClass().getResource("Chats.fxml"));
//                Scene chatsScene = new Scene(chatsView);
//                //now get the stage info...
//                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
//                window.setScene(chatsScene);
//                window.show();
//            } catch (IOException e) {
//                System.out.println(e.getMessage());
//            }
//
//        } else if(event.getSource() == LoginButton && username.isEmpty() || password.isEmpty() ) {
//        	System.out.println("test log in ");
//            warningDisplay("Please enter valid login details", Color.RED);
//        } else if((event.getSource() == LoginButton && !username.isEmpty() && !password.isEmpty()) && counter != 0) {
//                counter --;
//                warningDisplay(counter + " attempts remaining", Color.RED);
//        }
//            else if (event.getSource() == LoginButton && counter == 0){
//                try{
//                    connection();
//                    Parent resetPasswordView = FXMLLoader.load(getClass().getResource("ResetPassword.fxml"));
//                    Scene resetPasswordScene = new Scene(resetPasswordView);
//
//                    //now get the stage info...
//                    Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
//                    window.setScene(resetPasswordScene);
//                    window.show();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//        }
//        }


    /**
     * @param event
     */

    @FXML
    public void registrationButtonError(ActionEvent event) {
        String first = txtRegisterFirstName.getText();
        String last = txtRegisterLastName.getText();
        String user = txtRegisterUsername.getText();
        String email = txtRegisterEmail.getText();
        String password = txtRegisterPassword.getText();
        String code = txtRegisterSecurityCode.getText();

        if (first.isEmpty() || last.isEmpty() || user.isEmpty() || email.isEmpty()
                || password.isEmpty() || code.isEmpty()) {
            registerWarningDisplay("Please fill in all fields", Color.RED);
        } else if
        (!first.isEmpty() && !last.isEmpty() && !user.isEmpty() && !email.isEmpty()
                        && !password.isEmpty() && !code.isEmpty() && (code.length() != 4)) {
            registerWarningDisplay("Code must be four digits", Color.RED);
        } else {
            registerWarningDisplay("Success", Color.GREEN);
        }
    }

    /**
     * Registration.fxml
     * Checks to see if all registration credentials have been
     * filled in.
     * If the security code entered != 4 digits another warning
     * label is displayed.
     *
     * @param event
     */

    @FXML
    public void registerUser(ActionEvent event) throws IOException {

        String first = txtRegisterFirstName.getText();
        String last = txtRegisterLastName.getText();
        String username = txtRegisterUsername.getText();
        String email = txtRegisterEmail.getText();
        String password = String.valueOf(txtRegisterPassword);
        String passwordText = txtRegisterPassword.getText();
        String codeLength = txtRegisterSecurityCode.getText();
        String code = String.valueOf(txtRegisterSecurityCode);
        System.out.println(codeLength);


        try {
            connection();
            int codeInt = Integer.parseInt(codeLength);

//            String loggedIn = "TRUE";
//            String attempts = "2";

            user = new Account(first, last, username, email, passwordText, codeInt);
            user.setLoggedIn(true);
            user.setRemainingLoginAttempts(3);
            toServer.reset(); //Reset outputStream to clear cache.
            toServer.writeObject("1#" + first + "#" + last + "#" + username + "#" + email +
                    "#" + passwordText + "#" + codeLength);

        } catch (NumberFormatException e) {
            System.out.println("Code must be four digits");
        }

        if (first.isEmpty() || last.isEmpty() || username.isEmpty() || email.isEmpty()
                || passwordText.isEmpty() || code.isEmpty()) {
            registerWarningDisplay("Please fill in all fields", Color.RED);
        } else if
        (!first.isEmpty() && !last.isEmpty() && !username.isEmpty() && !email.isEmpty()
                        && !passwordText.isEmpty() && !codeLength.isEmpty() && (codeLength.length() != 4)) {
            registerWarningDisplay("Code must be four digits", Color.RED);
        } else {
            try {
//                Connection connection;
//                PreparedStatement preparedStatement;
//                connection = DriverManager.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/", "krishna", "08tgfexbf8");
//                String SQLQuery = "INSERT INTO USERS(ID,FIRSTNAME,LASTNAME,PASSWORD,EMAIL,SECURITY_CODE, LOGGEDIN, REMAINING_LOGIN_ATTEMPTS DATE)"
//                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
//                preparedStatement = connection.prepareStatement(SQLQuery);
//                Calendar calendar = Calendar.getInstance();
//                java.sql.Date date = new java.sql.Date(calendar.getTime().getTime());


//                preparedStatement.setString(1, username);
//                preparedStatement.setString(2, first);
//                preparedStatement.setString(3, last);
//                preparedStatement.setString(4, password);
//                preparedStatement.setString(5, email);
//                preparedStatement.setString(6, codeLength);
//                preparedStatement.setString(7, "TRUE");
//                preparedStatement.setString(8, ((Integer.toString(user.getRemainingLoginAttempts()))));
//                preparedStatement.setDate(9, date);

//                ResultSet resultSet = preparedStatement.executeQuery();
                registerWarningDisplay("Registration complete", Color.GREEN);

                Parent loginView = FXMLLoader.load(getClass().getResource("Chats.fxml"));
                Scene loginScene = new Scene(loginView);

                //now get the stage info...
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(loginScene);
                window.show();

            } catch (IOException e) {
                System.out.println(e.getMessage());

            }
        }
    }


    /**
     * Settings.fxml
     * Option deletes a users account from the database
     * and closes the connection.
     *
     * @param
     */

    public void deleteAccountPopOut(ActionEvent event) throws IOException {

        Parent popOutView = FXMLLoader.load(getClass().getResource("popOut.java"));
        Scene popOutScene = new Scene(popOutView);

        //now get the stage info...
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(popOutScene);
        window.show();
    }


    /**
     * Changes the users profile image to one of five
     * possible predetermined images.
     *
     * @param event
     */
    @FXML
    public void changeImage(ActionEvent event) {

    }

    /**
     * When the user clicks the delete account button their
     * account will be deleted and they will be returned
     * to the sign-in page.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    public void deleteAccount(ActionEvent event) throws IOException {
        if (event.getSource() == deleteButton) {
            String logoutProto = "9#" + user.getUserName();
            user.logout();
            toServer.reset();
            toServer.writeObject(logoutProto);

            Parent loginView = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Scene loginScene = new Scene(loginView);

            //now get the stage info...
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(loginScene);
            window.show();
        }
    }

    /**
     * ChangePassword.fxml
     * Changes the users password when they enter the correct credentials
     * and press the confirm button.
     * The method first checks to see if the user has entered text for both
     * fields, if not a label with a warning message is displayed.
     * The user is asked to confirm their choice of new password, if the new
     * passwords do no match a label with a warning message is displayed.
     *
     * If the credentials entered by the user are correct, the new password
     * is sent to the server with the old password, where it will be updated,
     * and the label is displayed so the user knows they have been successful.
     */

    @FXML
    public void changePassword() {

        try {
            String oldPass = currentPass.getText();
            String pass1 = newPass.getText();
            String pass2 = confirmPass.getText();
            if (oldPass.isEmpty() || pass1.isEmpty() || pass2.isEmpty()) {
                changePasswordStatus("Please complete all fields.", Color.RED);
            } else if (pass1.equals(pass2)) {
//                System.out.println(user.changePassword(oldPass, pass1));
                System.out.println(user.toString());

                if(user.changePassword(oldPass, pass1).equals("success")) {

                    toServer.reset();
                    toServer.writeObject("2#" + user.getUserName() + "#" + pass1);
                    String responseFromServer = (String) fromServer.readObject();
                    if (responseFromServer.equals("success")) {
                    	changePasswordStatus("Password successfully changed.", Color.GREEN);
                    }	
                } else {
                    changePasswordStatus("Passwords don't match.", Color.RED);
                }
            } else {
                changePasswordStatus("Passwords don't match.", Color.RED);
            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error try again");
        }
    }

    /**
     * *** TO BE INTEGRATED WITH THE METHOD resetPassword ABOVE ***
     * ResetPassword.fxml
     * Checks to make sure user enters valid credentials
     * when resetting their password.
     * Checks to see if password matches confirmed password.
     *
     * @param
     */

    @FXML
    public void resetPasswordButtonError() {
        try {
            String username = txtResetUsername.getText();
            String codeString = txtResetCode.getText();
            int code = Integer.parseInt(codeString);
            String pass1 = txtResetPassword.getText();
            String pass2 = txtResetPassword2.getText();

            if (username.isEmpty() || pass1.isEmpty() || pass2.isEmpty() || codeString.isEmpty()) {
                resetWarningDisplay("Please complete all fields.", Color.RED);
            } else if (pass1.equals(pass2)) {
                toServer.reset();
                toServer.writeObject("3#" + username + "#" + code + "#" + pass1);
                String responseFromServer = (String) fromServer.readObject();
                if (responseFromServer.equals("success")) {
                    resetWarningDisplay("Password successfully changed.", Color.GREEN);
                } else {
                    resetWarningDisplay("Passwords don't match.", Color.RED);
                }
            }
        } catch (IOException ex) {
            System.out.println("Error try again");

        } catch (NumberFormatException ex) {
            resetWarningDisplay("Please enter a valid credentials", Color.RED);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }



    /**
     *
     * @return
     */

//    @FXML
//    private ActionEvent sendMessage() {
//
//        try {
//            String messageToSend = inputMessage.getText();
//    		  if (!messageToSend.equals("")) {
//            		toServer.writeUTF("6#+" + "recipient" + "#" + messageToSend);
//			  }
//        } catch (IOException e) {
//            System.out.println("Could not send message");
//        }
//    }
//
//

    /**
     * ChatRoom.fxml
     * Enables a user to send a text message from their text box
     * to display to the rest of the Chat room.
     *
     * @param event
     */
    @FXML
    private void broadcastMessage(ActionEvent event) {
    	sendMessages.run();
//    	receiveMessages.run();
//	    try {
//	    	String messageToSend = chatRoomInput.getText();
//	    	if (!messageToSend.equals("")) {
//	    		toServer.writeObject("7#" + user.getUserName() + "#" + messageToSend);
//	    		chatRoomDisplay.setText(chatRoomDisplay.getText()
//	    			    + user.getUserName() + ": " + chatRoomInput.getText() + "\n");
//	    		chatRoomInput.clear();
//	    	}
////    		chatRoomDisplay.setText(chatRoomDisplay.getText() + receiveMessages() + "\n");
////		    chatRoomInput.clear();
//	    	receiveMessages();
//	    } catch (IOException e) {
//	    	System.out.println("Message could not send");
//	    }
	}

    
    Thread sendMessages = new Thread(new Runnable(){
    	@Override
    	public void run() {
    	    try {
    	    	String messageToSend = chatRoomInput.getText();
    	    	if (!messageToSend.equals("")) {
    	    		toServer.writeObject("7#" + user.getUserName() + "#" + messageToSend);
    	    		chatRoomDisplay.setText(chatRoomDisplay.getText()
    	    			    + user.getUserName() + " : " + messageToSend + "\n");
    	    		chatRoomInput.clear();
    	    	}
    	    	return;
//        		chatRoomDisplay.setText(chatRoomDisplay.getText() + receiveMessages() + "\n");
//    		    chatRoomInput.clear();
//    	    	receiveMessages();
    	    } catch (IOException e) {
    	    	System.out.println("Message could not send");
    	    }
    	}
    });
    
//    @FXML
//    private void broadcastMessage(ActionEvent event) {
//
////        if (event.getSource().equals(chatRoomSendButton)) {
//            chatRoomSendButton.setOnAction(event1 -> {
//                chatRoomDisplay.setText(chatRoomDisplay.getText()
//                        //null pointer exception currently as no username to get.
//                        + user.getUserName() + ": " + chatRoomInput.getText() + "\n");
//                chatRoomInput.clear();
//            });
//            try {
//                String messageToSend = chatRoomInput.getText();
//                toServer.writeObject("7#" + messageToSend);
//                System.out.println((String) fromServer.readObject());
//
//            } catch (IOException | ClassNotFoundException e) {
//                System.out.println("Message could not send");
//            }
//        }
////    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        if (user.isLoggedIn()) {
//            usernameDisplay.setText(user.getUserName());
//            usernameDisplay.setTextFill(Color.WHITE);
//
//        }
    }

//    public static void main(String[] args){
//        Controller client = new Controller("localhost");
//        client.run();
//    }

//    public void receiveMessages() {
////		while (user.isLoggedIn()) {
//			try {
//				String msg = (String) fromServer.readObject();
//				System.out.println( msg);
//				chatRoomDisplay.setText(chatRoomDisplay.getText() + msg + "\n");
//			    chatRoomInput.clear();
//			} catch (ClassNotFoundException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				System.out.println("Could not receive message.");
//			}
////		}
////		return null;
//	}
    
    Thread receiveMessages = new Thread(new Runnable(){
    	@Override
    	public void run() {
    		while (true) {
    			try {		
    				String msg = (String) fromServer.readObject();
    				System.out.println(msg);
    				String[] message = msg.split(":", 2);
    				if (message.length == 0) {
    					
    				} else if (message[0].matches("[A-Za-z0-9]* ")) {
        				System.out.println(msg);
        				System.out.println("2");
        				chatRoomDisplay.setText(chatRoomDisplay.getText() + msg + "\n");
    				}
    			} catch (ClassNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (IOException e) {
    				//System.out.println("Could not receive message.");
    				e.printStackTrace();
    			} 
    		}
    	}
    });
    
    

}



















