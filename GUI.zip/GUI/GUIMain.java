package GUI;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class GUIMain extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        primaryStage.setTitle("Krishna Messenger");
        primaryStage.setScene(new Scene(root, 700, 500));
        primaryStage.show();
    }

    public static void main(String[] args) {
//        if (args.length != 1) {
//            System.err.println("Usage: java LaunchClient hostname");
//        } else {
//            Controller client = new Controller(args[0]);
//            client.run();
//            Controller client = new Controller("localhost");
            launch(args);
        }


    }


