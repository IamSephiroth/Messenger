package GUI;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

/**
 * 
 * ServerSocket class to handle each clients. Each client has one thread.
 * It is not a Thread, it is Runnable. this is what thread runs. 
 * TODO register new user
 * TODO login existing user
 * TODO send message to the right client
 * TODO Client get message only after sending one -> fix it.
 * 
 * @author Miyo Takahashi
 * @version 2020-03-15
 * 
 * @param
 */
public class ClientManager implements Runnable {
	private Socket client = null;
	private ObjectOutputStream toClient;
	private ObjectInputStream fromClient;
	private String input; 
	
	// key is username, value is clientManager
	private static HashMap<String, ClientManager> clientMap =
			new HashMap<String, ClientManager>();
	// TODO add users to activeUser they they login and remove when they log out.
//	private static ArrayList<ClientManager> activeUsers =
//			new ArrayList<ClientManager>();

	/**
	 * Constructor of ClientManager class.
	 * comm with given client
	 * 
	 * @param client Incoming socket from a particular client.
	 */
	public ClientManager(Socket client) {
		this.client = client;
				
	}

	/**
	 * Given a username, return the associated ClientManager.
	 * 
	 * @return Object of ClientManager.
	 */
	public static ClientManager getClientManager(String userName) {
		return clientMap.get(userName);
	}
	/**
	 * 
	 * @param userName
	 * @param cm
	 */
	private static void removeClient(String userName, ClientManager cm) {
		clientMap.remove(userName, cm);
	}
	
	/**
	 * Add a new user name and ClientManager object generated on the user
	 * to clientMap.
	 * 
	 * @param userName unique user name to the user.
	 * @param cm ClientManager object that communicates with the associated user.
	 */
	private static void addClient(String userName, ClientManager cm) {
		clientMap.put(userName, cm);
	}
	/**
	 * To be executed when a client is connected.
	 * 
	 */
	public void run() {

//		while(true) {
			try {
				// what to send to/received from a client
				toClient = new ObjectOutputStream(client.getOutputStream());
				fromClient = new ObjectInputStream(client.getInputStream());
				input = (String) fromClient.readObject();
				//			/*
				//			 * show message that we got input, while we have input form the client
				//			 * if the input is of type Account, store as account info,
				//			 * if input is String, store as message. Stop here until receiving an input.
				//			 */
				//input = fromClient.readObject();
				// the client can send object of Account / MessageHandler
				// TODO receive string
				/*
				 * Switch based on the input number.
				 * 0 - login
				 * 1 - sign up
				 * 2 - change password
				 * 3 - reset password
				 * 4 - change security code
				 * 5 - reset security code
				 * 6 - send private chat
				 * 7 - send broadcast message
				 * 8 - log out
				 * 9 - delete account
				 * 10 - search for a chat
				 */
				loopLabel:
				while (input != null) {
					System.out.println("Got " + input + " from client");
					String param;
					String[] option = input.split("#", 2);
					param = option[1];
					switch (option[0])
					{
						case "0":
							login(param);
							break;
						case "1":
							signUp(param);
							break;
						case "2":
							changePassword(param);
							break;
						case "3":
							resetPassword(param);
							break;
						case "4":
							changeSecurityCode(param);
							break;
						case "5":
							resetSecurityCode(param);
							break;
						case "6":
							sendPrivateChat(param);
							break;
						case "7":
							broadcast(param);
							break;
						case "8":
							logout(param);
							break;
						case "9":
							deleteAccount(param);
							break;
						case "10":
//							searchChat(param);
							break;	
						case "11":
							terminateConnection(param);
							break loopLabel;
						case "12":
							showOnlineMap();
						default:
							System.out.println("Invalid command.");
							break;
					}
					input = (String) fromClient.readObject();
				}
			} catch (Exception e) {
			//	System.out.println("Error handling input from client");
				e.printStackTrace();
			}
		}
//	}


 
	/**
	 * TODO
	 * 
	 * @param input account info.
	 */
	private void signUp(String input) {
		/*
		 * Split the Account info first name and last name etc,
		 * and store in database.
		 */
		String[] accountDetail = input.split("#");
		String firstName = accountDetail[0];
		String lastName = accountDetail[1];
		String userName = accountDetail[2];
		String email = accountDetail[3];
		String password = accountDetail[4];
		String securityCodeString = accountDetail[5];
		int securityCode = Integer.parseInt(securityCodeString);
		addClient(userName, this);
		
		
			Connection c = null;
		    Statement stmt = null;
		      try {
		         Class.forName("org.postgresql.Driver");

		         System.out.println("Opened database successfully");

			     PreparedStatement preparedStatement;
			     c = DriverManager.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/", "krishna", "08tgfexbf8");
			     String SQLQuery = "INSERT INTO USERS(id,firstname,lastname,password,email,security_code, date)"
			            + " VALUES (?, ?, ?, ?, ?, ?, ?)";
				  c.setAutoCommit(false);
			     preparedStatement = c.prepareStatement(SQLQuery);

//				     Calendar calendar = Calendar.getInstance();
//					  DateTimeFormatter newDate = DateTimeFormatter.ofPattern("dd/mm/yy");
//					  java.sql.Date date = new java.sql.Date(calendar.getTime().getTime());
			   //  java.sql.Date date = new java.sql.Date(calendar.getTime().getTime());
				  Date date = new Date();
				  SimpleDateFormat pattern = new SimpleDateFormat("dd/MM/yy");

			     preparedStatement.setString(1, userName);
			     preparedStatement.setString(2, firstName);
			     preparedStatement.setString(3, lastName);
			     preparedStatement.setString(4, password);
			     preparedStatement.setString(5, email);
			     preparedStatement.setInt(6, securityCode);
			     preparedStatement.setString(7, pattern.format(date));

			     preparedStatement.executeUpdate();
		    
		  
			    preparedStatement.close();
		         c.commit();
		         c.close();
	      } catch (Exception e) {
		      	e.printStackTrace();
	         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
	         System.exit(0);
	      }
	      System.out.println("Records created successfully");
	
	}
	
	public String getUserName() {
		// TODO 
		return null;//this.getUserName();
	}
	
	// TODO log in check
	// TODO group chat

	/**
	 * Send message input to the current client.
	 * Generate an ClientManager object of the recipient, and call
	 * sendMessage method on that object.
	 * 
	 * @param param the recipient and the message body.
	 */
	private void sendPrivateChat(String param) {
		// TODO handle # in message if split method does not do it.
		String[] msgInfo = param.split("#");
		ClientManager target = getClientManager(msgInfo[1]);
		String sender = msgInfo[0];
		String msg = msgInfo[2];
		if (msg != null) {
			// TODO get sender info
			target.sendMessage(sender, msg);
		}
	}
	
	private void sendMessage(String from, String msg) {
		System.out.println("Reached sendMessage method in ClientManager class");
		try {
			toClient.reset();
			toClient.writeObject(from + " : " + msg);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error: sendMessage");
		}
	}
	
	
	/**
	 * Broadcast message to all users currently logged in.
	 * 
	 * @param param
	 */
	private void broadcast(String param) {
		String[] msgInfo = param.split("#");
		String sender = msgInfo[0];
		String msg = msgInfo[1];
//		String sender = this.getUserName();
	//	String msg = msgInfo[1];
//		Iterator<ClientManager> iter = new Iterator<ClientManager>(clientMap);
//		while (iter.hasNext()) {
//			iter.next();
		
		clientMap.forEach((username, clientManager) -> { if (!username.equals(sender) ) {
															clientManager.sendMessage(sender, msg);
														}});
//		ClientManager target = getClientManager(sender);
//			target.sendMessage(sender, msg);
		}
	
	/**
	 * 
	 * @param param
	 * @throws IOException
	 */
	public void login(String param) throws IOException {
		if (param.equals("#")) {
			toClient.writeObject("failure");//This handles the case where the client enters neither uername or password.
		}else {
			String firstname;
			String lastname;
			String securitycode;
			String email;
			String username;
			String password;
			String storedPassword = null;
			String[] loginInfo = param.split("#");
			if (loginInfo.length == 1) {
				toClient.writeObject("failure"); //This handles the case where the client only enters the username or the password but not both.
			} else {
				username = loginInfo[0];
				password = loginInfo[1];
				String queryPassword;
				String queryUser;
				queryPassword = "SELECT PASSWORD FROM USERS WHERE id='" + username +"';";
				queryUser = "SELECT * FROM USERS WHERE id='" + username +"';";
				Connection c = null;
				Statement stmt = null;
//				if (username == null || password == null){
//					toClient.writeObject("failure");
//				}
//				if(username.equals("")|| password.equals("")) {
//					toClient.writeObject("failure");
//				} else {
		
					try {
						Class.forName("org.postgresql.Driver");
						c = DriverManager
								.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/",
										"krishna", "08tgfexbf8");
						c.setAutoCommit(false);
						System.out.println("Opened database successfully");
		
						stmt = c.createStatement();
		
						ResultSet rs = stmt.executeQuery(queryPassword);
		
						while (rs.next()) {
							storedPassword = rs.getString("password");
						}
		
						ResultSet rs2 = stmt.executeQuery(queryUser);
						
		
						//storedPassword = "password";
		
						if (password.equals(storedPassword)) {
		
		// 				loggedIn = true;
							while (rs2.next()) {
								firstname = rs2.getString("firstname");
								lastname = rs2.getString("lastname");
								securitycode = rs2.getString("security_code");
								email = rs2.getString("email");
								addClient(username, this);
		
								toClient.writeObject("success#" + firstname + "#" + lastname + "#" + username + "#" +
										email + "#" + password + "#" + securitycode);
							}
		//				clientMap.forEach((username1, clientManager) -> {if(username1.equals(username))
		//				{
		//					try {
		//						clientManager.toClient.writeUTF("success#"+firstname+"#"+lastname+"#"+username+"#"+
		//								email+"#"+password+"#"+securitycode);
		//					} catch (IOException e) {
		//						e.printStackTrace();
		//					}
		//				}
		//						});
		
						} else {
							toClient.writeObject("failure");
						}
						rs.close();
						stmt.close();
						c.close();
					} catch (Exception e) {
						System.err.println(e.getClass().getName() + ": " + e.getMessage());
						System.exit(0);
					}
					System.out.println("Operation done successfully");
				}
//			}
		}
	}

	/**
	 * 
	 * @param param
	 */
	public void changePassword(String param) {
		String username;
		String newPassword;
		String[] info = param.split("#");
		username = info[0];
		newPassword = info[1];

		String queryUpdatePassword;
		queryUpdatePassword = "UPDATE USERS SET PASSWORD ='"+ newPassword +"' WHERE ID ='" + username + "';";

		Connection c = null;
		Statement stmt = null;
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager
					.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/",
							"krishna", "08tgfexbf8");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");


			stmt = c.createStatement();

			stmt.executeUpdate(queryUpdatePassword);
			stmt.close();
			c.commit();
			c.close();
			System.out.println("Operation done successfully");
			try {
				toClient.writeObject("success");
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}
		catch ( Exception e ) {
			try {
				toClient.writeUTF("failure");
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * @param param
	 * @throws IOException
	 */
	public void resetPassword(String param) throws IOException {
		String username;
		String securitycode;
		String newPassword;
		String storedSecuritycode = null;
		String querySecuritycode;
		String queryUpdatePassword;

		String[] info = param.split("#");
		username = info[0];
		securitycode = info[1];
		newPassword = info[2];

		querySecuritycode = "SELECT SECURITY_CODE FROM USERS WHERE ID = '" + username + "';";
		queryUpdatePassword = "UPDATE USERS SET PASSWORD ='"+newPassword+"' WHERE ID ='" + username + "';";



		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager
					.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/",
							"krishna", "08tgfexbf8");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");


			stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery(querySecuritycode);

			while ( rs.next() ) {
				storedSecuritycode = rs.getString("security_code");

			}

			rs.close();

			if(securitycode.equals(storedSecuritycode)) {

				stmt.executeUpdate(queryUpdatePassword);
				try {
					toClient.writeObject("success");
				}
				catch (IOException e) {
// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				try {
					toClient.writeObject("failure");
				}
				catch (IOException e) {
// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			stmt.close();
			c.commit();
			c.close();
		}
		catch ( Exception e ) {
			System.err.println( e.getClass().getName()+": "+ e.getMessage() );
			System.exit(0);
		}

	}
	
	/**
	 * 
	 * @param param
	 * @throws IOException
	 */
	public void changeSecurityCode(String param) throws IOException {
		String username;
		String currentSecurityCode;
		String newSecurityCode;
		
		String[] info = param.split("#");
		username = info[0];
		currentSecurityCode = info[1];
		newSecurityCode = info[2];
		
		String storedSecurityCode = "";
		// storedSecurityCode = -retrieve code for that user from database-  
		
		if(currentSecurityCode.equals(storedSecurityCode)) {
			// query to update code of the user in database
			toClient.writeUTF("success");
		}
		else {
			toClient.writeUTF("failure"); 
		}
		
	}
	
	/**
	 * 
	 * @param param
	 * @throws IOException
	 */
	public void resetSecurityCode(String param) throws IOException {
		String username;
		String password;
		String newSecurityCode;
		
		String[] info = param.split("#");
		username = info[0];
		password = info[1];
		newSecurityCode = info[2];
		
		String storedPassword = "";
		// storedPassword = -retrieve password for that user from database-
		
		if(password.equals(storedPassword)) {
			// query to update security code in database
			toClient.writeUTF("success");
		}
		else {
			toClient.writeUTF("failure");
		}
	}
	
	/**
	 * 
	 * @param param
	 */
	public void logOut(String param) {
		String username;
		
		String[] input = param.split("#", 0);
		username = input[0];
		// remove user from online list
		
		System.out.println(username + " has logged out.");
		
	}

	/**
	 * 
	 * @param param
	 */
	public void deleteAccount(String param) {
//		String username;
//		String[] input = param.split("#", 0);
//		username = input[0];

		String queryDeleteAccount;
		queryDeleteAccount = "DELETE FROM USERS WHERE ID = '" + param + "';";

		Connection c = null;
		Statement stmt = null; 
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager       
					.getConnection("jdbc:postgresql://mod-msc-sw1.cs.bham.ac.uk/",
		            "krishna", "08tgfexbf8");
	        c.setAutoCommit(false);
	        System.out.println("Opened database successfully");
		       

	        stmt = c.createStatement();
		       
		    stmt.executeUpdate(queryDeleteAccount);    
		    try {
		    	toClient.writeObject("success");
		    }
		    catch (IOException e) {
		    	// TODO Auto-generated catch block
		    	e.printStackTrace();
		    }        
		    stmt.close();
		    c.commit();
		    c.close();
		
		System.out.println(param + "'s account has been deleted.");
		}
		catch( Exception e ) {
			try {
				toClient.writeObject("failure");
			}
			catch (IOException e2) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}        
		}

	}
	
	/**
	 * 
	 * @param param
	 */
	public void terminateConnection(String param) {
		System.out.println("Close connection with Client");
		try {
			toClient.close();
			fromClient.close();
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	/**
	 * 
	 * @param param
	 */
	public void logout(String param) {
		removeClient(param, this);
		System.out.println(param + " has logged out.");
	}
	
	/**
	 * 
	 */
	public void showOnlineMap() {
		try {
			toClient.reset();
			toClient.writeObject(clientMap);
		} catch(IOException e) {
			System.out.println("Could not update online user list.");
		}
	}
	
//	/**
//	 * Send message input to the current client.
//	 * Call this method on the target(destination) client.
//	 * 
//	 * @param input message to the target.
//	 */
//	public void sendMessage(String param) {
//		String recepient;
//		String msg;
//		String[] loginInfo = param.split("#", 0);
//		recepient = loginInfo[0];
//		msg = loginInfo[1];
//		
//	}
	
}

