package GUI;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class popOut extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

            primaryStage = new Stage();
            VBox decision = new VBox();
            Label delete = new Label("Are you sure you want to delete your account?");
            decision.setAlignment(Pos.CENTER);
            delete.setAlignment(Pos.TOP_CENTER);

            Button yes = new Button("Yes");
            Button no = new Button("No");

            decision.getChildren().add(delete);
            decision.getChildren().add(yes);
            decision.getChildren().add(no);

            Scene stageScene = new Scene(decision, 300, 300);
            primaryStage.setScene(stageScene);
            primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
